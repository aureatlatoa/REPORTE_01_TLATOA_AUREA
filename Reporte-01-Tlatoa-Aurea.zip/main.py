from lifestore_file import lifestore_products
from lifestore_file import lifestore_sales
from lifestore_file import lifestore_searches

#Acceso

usuario_admin = "Lifestore2020"
contraseña_admin = "24159093"

usuario_ingreso = input('Ingresa tu usuario: ')
contraseña_ingreso = input('Ingresa tu contraseña: ')

if usuario_ingreso == usuario_admin and contraseña_ingreso == contraseña_admin:
    print('Bienvenido a Lifestore')
else:
    print('Lo siento, no tienes acceso')

###Consigna 1:
id_producto = 0
for producto in lifestore_products:
    print(producto[id_producto])

contador = 0
total_ventas = []
for producto in lifestore_products:
    for venta in lifestore_sales:
        if producto[0] == venta[1]:
            contador += 1

    formato_ideal = [producto[0], contador]
    total_ventas.append(formato_ideal)
    contador = 0

for total in total_ventas:
    print('El producto: ', total[0], ' se vendió: ', total[1])
print(total_ventas)  #[2, 13] id y numero de venta

##Se ordena el listado de acuerdo al mayor número de ventas contenidos en la lista ventas_ordenadas
ventas_ordenadas = []

while total_ventas:
    minimo = total_ventas[0][1]
    lista_actual = total_ventas[0]
    for venta in total_ventas:
        if venta[1] > minimo:
            minimo = venta[1]
            lista_actual = venta
    ventas_ordenadas.append(lista_actual)
    total_ventas.remove(lista_actual)
print(ventas_ordenadas)

#Una vez ordenada se imprimen solo los 50 productos con mayores ventas
#for mayor in ventas_ordenadas:
#print('El producto: ', mayor[0], ' se vendió: ', mayor[1])

#Listado de los 50 productos mas vendidos Generar un listado de los 50 productos con mayores ventas
for indice in range(0, 50):
    print("\n El producto: ", ventas_ordenadas[indice][0], "Se vendió: ",
          ventas_ordenadas[indice][1], "veces")

#Los 50 productos con menores ventas
for indice in range(46, 96):
    print("El producto: ", ventas_ordenadas[indice][0], "Se vendió: ",
          ventas_ordenadas[indice][1], "veces")

#Búsquedas por producto
contador1 = 0
total_searches = []
for producto in lifestore_products:
    for busqueda in lifestore_searches:
        if producto[0] == busqueda[1]:
            contador1 += 1

    formato_ideal2 = [producto[0], contador1]
    total_searches.append(formato_ideal2)
    contador1 = 0

for totals in total_searches:
    print('El producto: ', totals[0], ' se buscó: ', totals[1])
print(total_searches)

#Ordenada
#Esta lista va del producto menor buscado al mayor buscado
busquedas_ordenadas = []

while total_searches:
    minimo = total_searches[0][1]
    lista_actual1 = total_searches[0]
    for busqueda in total_searches:
        if busqueda[1] < minimo:
            minimo = busqueda[1]
            lista_actual1 = busqueda
    busquedas_ordenadas.append(lista_actual1)
    total_searches.remove(lista_actual1)
print(busquedas_ordenadas)

#Productos con menores búsquedas
for indice1 in range(0, 96):
    print("\n El producto: ", busquedas_ordenadas[indice1][0], "Se buscó: ",
          busquedas_ordenadas[indice1][1], "veces")

#2) Productos por reseña en el servicio a partir del análisis de categorías con mayores ventas y categorías con mayores búsquedas
##"20 productos con mejor score" considerando las devoluciones (refund)

contador2 = 0
total_dev = []
for producto in lifestore_products:
    for devolucion in lifestore_sales:
        if producto[0] == devolucion[4]:
            contador2 += 1
    formato_ideal2 = [producto[0], contador2]
    total_dev.append(formato_ideal2)
    contador2 = 0

for totaldev in total_dev:
    print('El producto: ', totaldev[0], ' se devolvió: ', totaldev[1], "veces")
print(total_dev)
#Muestra los 20 productos con mayores devoluciones considerando el número de reseñas
for indice2 in range(0, 20):
    print("\n El producto: ", total_dev[indice2][0], "Se devolvió: ",
          total_dev[indice2][1], "veces")

###3)Total de ingresos
#Total de ingresos y ventas promedio mensuales,
#total anual y meses con más ventas al año

ingresos_totales = []
contador3 = 0
for precio in lifestore_products:
    for ventast in ventas_ordenadas:
        if precio[2] == ventast[1]:
            contador3 += 1
    formato_ideal3 = [precio[2], contador3]
    ingresos_totales.append(formato_ideal3)
    contador3 = 0
print(ingresos_totales)
